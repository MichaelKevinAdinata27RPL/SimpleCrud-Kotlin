package com.kevin.simplecrud.User

data class Users(
    val id: String?,
    val nama: String?,
    val alamat: String?,
    val gender: String?
)