package com.kevin.simplecrud.Inventaris

data class Inventaris(
    val id_barang: String?,
    val nama_barang: String?,
    val jenis_barang: String?,
    val jumlah_barang: String?
)