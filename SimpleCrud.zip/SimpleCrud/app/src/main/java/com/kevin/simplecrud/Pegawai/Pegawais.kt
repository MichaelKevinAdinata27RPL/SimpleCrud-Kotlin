package com.kevin.simplecrud.Pegawai

data class Pegawais(
    val id: String?,
    val nama: String?,
    val alamat: String?,
    val no_telp: String?
)