package com.kevin.simplecrud.Guru

data class Gurus(
    val nip: String?,
    val nama_guru: String?,
    val alamat_guru: String?,
    val no_telp_guru: String?,
    val gender: String?,
    val mata_pelajaran: String?,
    val hobi: String?
)